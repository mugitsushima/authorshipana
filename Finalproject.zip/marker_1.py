#1.coordinate adj vs non_coordinate adj(e.g. quick, lazy fox vs. quick lazy fox)
import os
import nltk
nltk.download('averaged_perceptron_tagger')
from nltk import pos_tag
import pandas as pd

folder_path = "/Users/y.taisei/Desktop/submit_python/archive"  
group_prefixes = ["Cleveland"]  # ファイルグループ

# ファイルを処理して形容詞の数をカウントする関数
def process_file(file_path):
    with open(file_path, "r",encoding="utf-8") as file:
        text = file.read()

    tokens = nltk.word_tokenize(text)
    tagged_tokens = pos_tag(tokens)

    count = 0
    count1 = 0
    count2 = 0

    for i in range(len(tagged_tokens)):
        word1, pos1 = tagged_tokens[i]
        if pos1.startswith('JJ'):
            count += 1

    
    for i in range(len(tagged_tokens) - 2):
        word1, pos1 = tagged_tokens[i]
        word2, pos2 = tagged_tokens[i + 1]
        word3, pos3 = tagged_tokens[i + 2]

        
        if pos1.startswith('JJ') and pos2 == ',' and pos3.startswith('JJ'):
            count1 += 1
            #print(word1,word2,word3)
        elif pos1.startswith('JJ') and pos2 == 'CC' and pos3.startswith('JJ'):#JJ:Adjective,CC:Coordinating conjunction
            count1 += 1
        elif pos1.startswith('JJ') and not pos2 == ',' and pos3.startswith('JJ'):
            count2 += 1
            #print(word1,word2,word3)
        elif pos1.startswith('JJ') and pos2.startswith('JJ'):
            count2 += 1
            #print(word1,word2,word3)

    return count, count1, count2


file_groups = {}  # ファイルグループとそのカウントを格納する辞書

# フォルダ内のファイルを処理する
for file_name in os.listdir(folder_path):
    file_path = os.path.join(folder_path, file_name)
    if os.path.isfile(file_path):
        group_name = None
        for prefix in group_prefixes:
            if file_name.startswith(prefix):
                group_name = prefix
                break
        if group_name is None:
            continue

        if group_name not in file_groups:
            file_groups[group_name] = {
                "total_adj_count": 0,
                "coordinate_adj_count": 0,
                "non_coordinate_adj_count": 0,
                "file_count": 0
            }
        count, count1, count2 = process_file(file_path)
        file_groups[group_name]["total_adj_count"] += count
        file_groups[group_name]["coordinate_adj_count"] += count1
        file_groups[group_name]["non_coordinate_adj_count"] += count2
        file_groups[group_name]["file_count"] += 1

#print(file_groups)
averages = {}
for group_name, group_data in file_groups.items():
    average_total = group_data["total_adj_count"] / group_data["file_count"]
    average_coordinate = group_data["coordinate_adj_count"] / group_data["file_count"]
    average_non_coordinate = group_data["non_coordinate_adj_count"] / group_data["file_count"]

    #authorship marker1
    value = group_data["coordinate_adj_count"] /  group_data["non_coordinate_adj_count"]  
    
    averages[group_name] = {
    "average_total_adjs": average_total,
    "average_coordinate_adjs": average_coordinate,
    "average_non_coordinate_adjs": average_non_coordinate,
    "authorship_value": value,
    }


sorted_groups = sorted(averages.items(), key=lambda x: abs(x[1]["authorship_value"] - averages["Cleveland"]["authorship_value"]))#Absolute value
for group_name, group_data in sorted_groups:
    #if group_name != "Cleveland":
    print()
    print("Group:", group_name)
    print("Difference in Authorship value with Group('Cleveland'):", abs(group_data["authorship_value"] - averages["Cleveland"]["authorship_value"]))
    print("Average Total adjs:", group_data["average_total_adjs"])
    print("Average coordinate adjs:", group_data["average_coordinate_adjs"])
    print("Average non-coordinate adjs:", group_data["average_non_coordinate_adjs"])
    print()
    
    #authorship marker1
    if group_data["authorship_value"] > 1:
        judge=1;
        print("coordinate adjective is dominate.") #Cleveland has the authorship_value > 0 , so count ++1;
        
    elif group_data["authorship_value"] < 1:
        judge=0;
        print(group_data["authorship_value"])
        print("non-coordiante adjective is dominate.")
    else:
        print("The number of the coordinate adjective equals the number of the non-coordinate adjective.")

    #print("Authorship feature Value:", group_data["authorship_value"])

      
results_df = pd.DataFrame(columns=["File", "Difference in Authorship Value", "Total adjs", "coordinate adjs", "non-coordinate adjs","result"])

for file_name in os.listdir(folder_path):
    #print(file_name)
    file_path = os.path.join(folder_path, file_name)
    if os.path.isfile(file_path):
        #if not any(file_name.startswith(prefix) for prefix in group_prefixes):
            file_data = {
                "total_adj_count": 0,
                "coordinate_adj_count": 0,
                "non_coordinate_adj_count": 0,
            }
            count, count1, count2 = process_file(file_path)
            
            file_data["total_adj_count"] += count
            file_data["coordinate_adj_count"] += count1
            file_data["non_coordinate_adj_count"] += count2

            total = file_data["total_adj_count"]
            coordinate = file_data["coordinate_adj_count"]
            non_coordinate = file_data["non_coordinate_adj_count"]

            value = file_data["coordinate_adj_count"] / file_data["non_coordinate_adj_count"]


            print()
            print("File:", file_name)
            print("Difference in Authorship value with 'Cleveland' group:", abs(value - averages["Cleveland"]["authorship_value"]))
            print("Total adjs:", total)
            print("coordinate adjs:", coordinate)
            print("non-coordinate adjs:", non_coordinate)
            print()

            if value > 1:
                judge = 0
                print("Coordinate adjective is dominant.")
            elif value < 1:
                judge = 1
                print("Non-coordinate adjective is dominant.")
            else:
                print("The number of coordinate adjectives equals the number of non-coordinate adjectives.")


            results_df = results_df.append({
                "File": file_name,
                "Difference in Authorship Value": abs(value - averages["Cleveland"]["authorship_value"]),
                "Total adjs": total,
                "coordinate adjs": coordinate,
                "non-coordinate adjs": non_coordinate,
                "result": judge,
            }, ignore_index=True)

results_df.sort_values("File", inplace=True)  # ファイル名をアルファベット順にソート
results_df.to_excel("/Users/y.taisei/Desktop/submit_python/results_1.xlsx", index=False)


