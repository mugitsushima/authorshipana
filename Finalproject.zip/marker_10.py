#10.count NUMBER in text(e.g. in 1934, Jun 2)
import os
import nltk
import pandas as pd

folder_path = "/Users/y.taisei/Desktop/submit_python/archive"  
group_prefixes = ["Cleveland"]

# Function to process a file and count the occurrence of numbers
def process_file(file_path):
    with open(file_path, "r") as file:
        text = file.read()

    tokens = nltk.word_tokenize(text)
    pos_tags = nltk.pos_tag(tokens)

    number_count = 0

    for word, pos in pos_tags:
        if pos == 'CD':  # CD tag represents numbers
            number_count += 1

    return number_count


file_groups = {}  # Dictionary to store file groups and their counts

# Process files in the folder
for file_name in os.listdir(folder_path):
    file_path = os.path.join(folder_path, file_name)
    if os.path.isfile(file_path):
        group_name = None
        for prefix in group_prefixes:
            if file_name.startswith(prefix):
                group_name = prefix
                break
        if group_name is None:
            continue

        if group_name not in file_groups:
            file_groups[group_name] = {
                "number_count": 0,
                "file_count": 0
            }
        number_count = process_file(file_path)
        file_groups[group_name]["number_count"] += number_count
        file_groups[group_name]["file_count"] += 1


averages = {}
for group_name, group_data in file_groups.items():
    average_numbers = group_data["number_count"] / group_data["file_count"]

    # Authorship marker: Number count
    value = average_numbers

    averages[group_name] = {
        "average_numbers": average_numbers,
        "authorship_value": value
    }

sorted_groups = sorted(averages.items(), key=lambda x: abs(x[1]["authorship_value"] - averages["Cleveland"]["authorship_value"]))
for group_name, group_data in sorted_groups:
    print()
    print("Group:", group_name)
    print("Difference in Authorship value with Group('Cleveland'):", abs(group_data["authorship_value"] - averages["Cleveland"]["authorship_value"]))
    print("Average Numbers:", group_data["average_numbers"])
    print()

    if group_data["authorship_value"] > averages["Cleveland"]["authorship_value"]:
        print("More Numbers")  # Cleveland has the highest authorship value, so count++
    elif group_data["authorship_value"] < averages["Cleveland"]["authorship_value"]:
        print("Fewer Numbers")
    else:
        print("Same number of Numbers")

results_df = pd.DataFrame(columns=["File", "Difference in Authorship Value", "Numbers","result"])

for file_name in os.listdir(folder_path):
    #print(file_name)
    file_path = os.path.join(folder_path, file_name)
    if os.path.isfile(file_path):
            file_data = {
               "number_count": 0,
            }
            number_count = process_file(file_path)
            file_data["number_count"] += number_count

            numbers = file_data["number_count"]
            

            value = numbers
            
            print("File:", file_name)
            print("Difference in Authorship value with 'Cleveland' group:", abs(value - averages["Cleveland"]["authorship_value"]))
            print("Numbers:",numbers)
            print()

            if abs(value - averages["Cleveland"]["authorship_value"]) < 150:
                judge = 1
                print("The text is more likely written by Cleveland.")
            elif abs(value - averages["Cleveland"]["authorship_value"]) > 150:
                judge = 0
                print("The text is more likely written by a different author.")
        
            results_df = results_df.append({
                "File": file_name,
                "Difference in Authorship Value": abs(value - averages["Cleveland"]["authorship_value"]),
                "Numbers": numbers,
                "result": judge,
            }, ignore_index=True)

results_df.sort_values("File", inplace=True)  # ファイル名をアルファベット順にソート
results_df.to_excel("/Users/y.taisei/Desktop/submit_python/results_10.xlsx", index=False)

