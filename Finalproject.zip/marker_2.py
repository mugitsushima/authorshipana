#2.tense verbs vs modalized verbs
import os
import nltk
import pandas as pd

folder_path = "/Users/y.taisei/Desktop/submit_python/archive" 
group_prefixes = ["Cleveland"] 

# Function to process a file and count tense and modalized verbs
def process_file(file_path):
    with open(file_path, "r") as file:
        text = file.read()

    tokens = nltk.word_tokenize(text)
    pos_tags = nltk.pos_tag(tokens)

    tense_verbs_count = 0
    modalized_verbs_count = 0
    total_verbs_count = 0

    for word, pos in pos_tags:
        if pos.startswith('VB'):  # all verbs
            total_verbs_count += 1

    for i in range(len(pos_tags) - 2):
        word1, pos1 = pos_tags[i]
        word2, pos2 = pos_tags[i + 1]
        word3, pos3 = pos_tags[i + 2]

        if pos1 == 'MD':
            modalized_verbs_count += 1  # modalized verbs

        if not pos1.startswith('VB'):
            if pos2 == 'VBD' or pos2 == 'VBG' or pos2 == 'VBN' or pos2 == 'VBP' or pos2 == 'VBZ':
                if not pos3.startswith('VB'):
                    tense_verbs_count += 1

    return total_verbs_count, tense_verbs_count, modalized_verbs_count


file_groups = {}  # Dictionary to store file groups and their counts

# Process files in the folder
for file_name in os.listdir(folder_path):
    file_path = os.path.join(folder_path, file_name)
    if os.path.isfile(file_path):
        group_name = None
        for prefix in group_prefixes:
            if file_name.startswith(prefix):
                group_name = prefix
                break
        if group_name is None:
            continue

        if group_name not in file_groups:
            file_groups[group_name] = {
                "total_verbs_count": 0,
                "tense_verbs_count": 0,
                "modalized_verbs_count": 0,
                "file_count": 0
            }
        total_count, tense_count, modalized_count = process_file(file_path)
        file_groups[group_name]["total_verbs_count"] += total_count
        file_groups[group_name]["tense_verbs_count"] += tense_count
        file_groups[group_name]["modalized_verbs_count"] += modalized_count
        file_groups[group_name]["file_count"] += 1


averages = {}
for group_name, group_data in file_groups.items():
    average_total = group_data["total_verbs_count"] / group_data["file_count"]
    average_tense = group_data["tense_verbs_count"] / group_data["file_count"]
    average_modalized = group_data["modalized_verbs_count"] / group_data["file_count"]

    #authorship marker1
    value = group_data["tense_verbs_count"] / group_data["modalized_verbs_count"]
    
    averages[group_name] = {
    "average_total_verbs": average_total,
    "average_tense_verbs": average_tense,
    "average_modalized_verbs": average_modalized,
    "authorship_value": value,
    }

sorted_groups = sorted(averages.items(), key=lambda x: abs(x[1]["authorship_value"] - averages["Cleveland"]["authorship_value"]))
for group_name, group_data in sorted_groups:
    #if group_name != "Cleveland":

    print("Group:", group_name)
    print("Difference in Authorship value with Group('Cleveland'):", abs(group_data["authorship_value"] - averages["Cleveland"]["authorship_value"]))
    print("Average Total Verbs:", group_data["average_total_verbs"])
    print("Average Tense Verbs:", group_data["average_tense_verbs"])
    print("Average Modalized Verbs:", group_data["average_modalized_verbs"])
    print()
    
    #authorship marker1
    if group_data["authorship_value"] > 1:
        judge=1;
        print("Tensed Verbs is dominate.") #Cleveland has the authorship_value > 0 , so count ++1;
        
    elif group_data["authorship_value"] < 1:
        judge=0;
        print("Modalized Verbs is dominate.")
    else:
        print("The number of Tensed Verbs equals the number of Modalized Verbs.")

    #print("Authorship feature Value:", group_data["authorship_value"])

results_df = pd.DataFrame(columns=["File", "Difference in Authorship Value", "Total Verbs", "Tense Verbs", "Modalized Verbs","result"])

for file_name in os.listdir(folder_path):
    #print(file_name)
    file_path = os.path.join(folder_path, file_name)
    if os.path.isfile(file_path):
        #if not any(file_name.startswith(prefix) for prefix in group_prefixes):
            file_data = {
                "total_verbs_count": 0,
                "tense_verbs_count": 0,
                "modalized_verbs_count": 0,
            }
            count, count1, count2 = process_file(file_path)
            
            file_data["total_verbs_count"] += count
            file_data["tense_verbs_count"] += count1
            file_data["modalized_verbs_count"] += count2

            total = file_data["total_verbs_count"]
            tense = file_data["tense_verbs_count"]
            modalized = file_data["modalized_verbs_count"]

            value = file_data["tense_verbs_count"] / file_data["modalized_verbs_count"]


            print()
            print("File:", file_name)
            print("Difference in Authorship value with 'Cleveland' group:", abs(value - averages["Cleveland"]["authorship_value"]))
            print("Total verbs:", total)
            print("Tense verbs:", tense)
            print("Modalized verbs:", modalized)
            print()

            if value > 1:
                judge = 1
                print("Tense verb is dominant.")
            elif value < 1:
                judge = 0
                print("Modalized verb is dominant.")
            else:
                print("The number of tense verbs equals the number of modalized verbs.")


            results_df = results_df.append({
                "File": file_name,
                "Difference in Authorship Value": abs(value - averages["Cleveland"]["authorship_value"]),
                "Total Verbs": total,
                "Tense Verbs": tense,
                "Modalized Verbs": modalized,
                "result": judge,
            }, ignore_index=True)

results_df.sort_values("File", inplace=True)  # ファイル名をアルファベット順にソート
results_df.to_excel("/Users/y.taisei/Desktop/submit_python/results_2.xlsx", index=False)




