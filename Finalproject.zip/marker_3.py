#3.type and token
import os
import nltk
from nltk import FreqDist
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import pandas as pd

folder_path = "/Users/y.taisei/Desktop/submit_python/archive"
group_prefixes = ["Cleveland"] 

def preprocess_text(text):
    # Convert to lowercase
    text = text.lower()
    # Remove stopwords
    stop_words = set(stopwords.words('english'))
    word_tokens = word_tokenize(text)
    filtered_text = [word for word in word_tokens if word not in stop_words]
    return filtered_text

def calculate_type_token_ratio(text):
    tokens = preprocess_text(text)
    # Calculate type and token counts
    type_count = len(set(tokens))
    token_count = len(tokens)
    # Calculate type-token ratio
    ttr = type_count / token_count
    return type_count,token_count,ttr

file_groups = {}  # Dictionary to store file groups and their TTRs

# Process files in the folder
for file_name in os.listdir(folder_path):
    file_path = os.path.join(folder_path, file_name)
    if os.path.isfile(file_path):
        group_name = None
        for prefix in group_prefixes:
            if file_name.startswith(prefix):
                group_name = prefix
                break
        if group_name is None:
            continue

        if group_name not in file_groups:
            file_groups[group_name] = []

        with open(file_path, "r") as file:
            text = file.read()
            type_count,token_count,ttr = calculate_type_token_ratio(text)
            file_groups[group_name].append(ttr)

averages = {}  # Dictionary to store average TTRs for each group
for group_name, ttrs in file_groups.items():
    average_ttr = sum(ttrs) / len(ttrs)
    averages[group_name] = average_ttr

# Sort groups by their average TTR in ascending order
sorted_groups = sorted(averages.items(), key=lambda x: x[1])

#print("Authorship analysis based on Type-Token Ratio (TTR):\n")
for group_name, average_ttr in sorted_groups:
    print("Group:", group_name)
    print("type:",type_count)
    print("token:",token_count)
    print("Average TTR:", average_ttr)
    # Determine the author based on TTR
    if abs(average_ttr -  averages["Cleveland"]) <0.07:
        print("The text is more likely written by Cleveland.")
    elif abs(average_ttr - averages["Cleveland"]) >0.07:
        print("The text is more likely written by a different author.")
    print()

results_df = pd.DataFrame(columns=["File", "Difference in Authorship Value","type","token","result"])

for file_name in os.listdir(folder_path):
    file_path = os.path.join(folder_path, file_name)
    if os.path.isfile(file_path):
            with open(file_path, "r") as file:
                text = file.read()
                type_count,token_count,ttr = calculate_type_token_ratio(text)
            
                print("File:", file_name)
                print("Difference in Authorship value with 'Cleveland' group:", abs(ttr - averages["Cleveland"]))
                print("type:",type_count)
                print("token:",token_count)
                print()

                if abs(ttr - averages["Cleveland"]) < 0.07:
                    judge = 1
                    print("The text is more likely written by Cleveland.")
                elif abs(ttr - averages["Cleveland"]) > 0.07:
                    judge = 0
                    print("The text is more likely written by a different author.")

                results_df = results_df.append({
                    "File": file_name,
                    "Difference in Authorship Value": abs(ttr - averages["Cleveland"]),
                    "type":type_count,
                    "token":token_count,
                    "result": judge,
                }, ignore_index=True)

results_df.sort_values("File", inplace=True)  # ファイル名をアルファベット順にソート
results_df.to_excel("/Users/y.taisei/Desktop/submit_python/results_3.xlsx", index=False)


        
      
