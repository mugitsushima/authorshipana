#5. most frequent tense verb 

import os
import nltk
import pandas as pd
from nltk import pos_tag
from collections import Counter

nltk.download('averaged_perceptron_tagger')

folder_path = "/Users/y.taisei/Desktop/submit_python/archive"
group_prefixes = ["Cleveland"]

# 動詞の時制を数える関数
def count_verb_tenses(tokens):
    pos_tags = pos_tag(tokens)

    verb_tenses = []
    for word, pos in pos_tags:
        if pos.startswith('VB'):
            verb_tenses.append(pos)

    return Counter(verb_tenses)

file_groups = {}  # ファイルグループごとのデータを格納する辞書

# フォルダ内のファイルを処理する
for file_name in os.listdir(folder_path):
    file_path = os.path.join(folder_path, file_name)
    if os.path.isfile(file_path):
        group_name = None
        for prefix in group_prefixes:
            if file_name.startswith(prefix):
                group_name = prefix
                break
        if group_name is None:
            continue

        if group_name not in file_groups:
            file_groups[group_name] = {
                "verb_tenses": [],
                "most_verb_tense":"",
                "file_count": 0
            }

        with open(file_path, "r") as file:
            text = file.read()
            tokens = nltk.word_tokenize(text)
            verb_tenses = count_verb_tenses(tokens)
            file_groups[group_name]["verb_tenses"].append(verb_tenses)
            file_groups[group_name]["file_count"] += 1

# 各グループの最頻動詞時制を表示する
for group_name, group_data in file_groups.items():
    print()
    print("Group:", group_name)
    print("File Count:", group_data["file_count"])

    # 最頻動詞時制を計算する
    total_tenses = Counter()
    for verb_tenses in group_data["verb_tenses"]:
        total_tenses += verb_tenses
    most_common_tense = total_tenses.most_common(1)
    file_groups[group_name]["most_verb_tense"]=most_common_tense[0][0]
    if most_common_tense:
        print("Most Common Verb Tense:", most_common_tense[0][0])
    else:
        print("No verb tenses found.")

    print()

results_df = pd.DataFrame(columns=["File","verb","result"])

for file_name in os.listdir(folder_path):
    file_path = os.path.join(folder_path, file_name)
    if os.path.isfile(file_path):
        file_data = {
            "verb_tenses": [],
        }
        with open(file_path, "r") as file:
            text = file.read()
            tokens = nltk.word_tokenize(text)
            verb_tense = count_verb_tenses(tokens)
            file_data["verb_tenses"].append(verb_tense)

            print("File:", file_name)
            print(verb_tense)

            total_tenses = Counter()
            for verb_tenses in file_data["verb_tenses"]:
                total_tenses += verb_tenses
            most_common_tense = total_tenses.most_common(1)
            if most_common_tense:
                judge = most_common_tense[0][0]
                print("Most Common Verb Tense:", most_common_tense[0][0])
            else:
                judge = None
                print("No verb tenses found.")
                
            if judge == file_groups["Cleveland"]["most_verb_tense"]:
            	identify = 1
            else:
            	identify = 0
            print(file_groups["Cleveland"]["most_verb_tense"])

            print()

            results_df = results_df.append({
                "File": file_name,
                "verb": judge,
                "result":identify,
            }, ignore_index=True)

results_df.sort_values("File", inplace=True)  # ファイル名をアルファベット順にソート
results_df.to_excel("/Users/y.taisei/Desktop/submit_python/results_5.xlsx", index=False)



        
      





