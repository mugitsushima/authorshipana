#6.percent number of words in one sentence
import os
import nltk
import pandas as pd

folder_path = "/Users/y.taisei/Desktop/submit_python/archive" 
group_prefixes = ["Cleveland"]


def process_file(file_path):
    with open(file_path, "r") as file:
        text = file.read()

    sentences = nltk.sent_tokenize(text)  # Tokenize into sentences
    total_words_count = 0
    total_sentences_count = len(sentences)

    for sentence in sentences:
        tokens = nltk.word_tokenize(sentence)
        total_words_count += len(tokens)

    return total_words_count, total_sentences_count


file_groups = {}  # Dictionary to store file groups and their counts

# Process files in the folder
for file_name in os.listdir(folder_path):
    file_path = os.path.join(folder_path, file_name)
    if os.path.isfile(file_path):
        group_name = None
        for prefix in group_prefixes:
            if file_name.startswith(prefix):
                group_name = prefix
                break
        if group_name is None:
            continue

        if group_name not in file_groups:
            file_groups[group_name] = {
                "total_words_count": 0,
                "total_sentences_count": 0,
                "file_count": 0
            }
        total_words, total_sentences = process_file(file_path)
        file_groups[group_name]["total_words_count"] += total_words
        file_groups[group_name]["total_sentences_count"] += total_sentences
        file_groups[group_name]["file_count"] += 1


averages = {}
for group_name, group_data in file_groups.items():
    average_words = group_data["total_words_count"] / group_data["total_sentences_count"]

    averages[group_name] = {
        "average_words_per_sentence": average_words
    }

sorted_groups = sorted(averages.items(), key=lambda x: abs(x[1]["average_words_per_sentence"] - averages["Cleveland"]["average_words_per_sentence"]))
for group_name, group_data in sorted_groups:
    print()
    print("Group:", group_name)
    print("Difference in Average Words per Sentence with Group('Cleveland'):", abs(group_data["average_words_per_sentence"] - averages["Cleveland"]["average_words_per_sentence"]))
    print("Average Words per Sentence:", group_data["average_words_per_sentence"])
    print()

    

results_df = pd.DataFrame(columns=["File", "Difference in Average Words per Sentence", "total words count","total sentences count","Average Words per Sentence","result"])

for file_name in os.listdir(folder_path):
    #print(file_name)
    file_path = os.path.join(folder_path, file_name)
    if os.path.isfile(file_path):
            file_data = {
                "total_words_count": 0,
                "total_sentences_count": 0,
            }
            total_words, total_sentences = process_file(file_path)
            file_data["total_words_count"] += total_words
            file_data["total_sentences_count"] += total_sentences

            words=file_data["total_words_count"]
            sentences=file_data["total_sentences_count"]

            value = file_data["total_words_count"] / file_data["total_sentences_count"]
            
            print("File:", file_name)
            print("Difference in Average Words per Sentence with Group('Cleveland') :", abs(value - averages["Cleveland"]["average_words_per_sentence"]))
            print("Average Words per Sentence:",value)
            print()

            if abs(value - averages["Cleveland"]["average_words_per_sentence"]) < 5.0:
                judge = 1
                print("The text is more likely written by Cleveland.")
            elif abs(value - averages["Cleveland"]["average_words_per_sentence"]) > 5.0:
                judge = 0
                print("The text is more likely written by a different author.")
        
            results_df = results_df.append({
                "File": file_name,
                "Difference in Average Words per Sentence": abs(value - averages["Cleveland"]["average_words_per_sentence"]),
                "total words count": words,
                "total sentences count": sentences,
                "Average Words per Sentence": value,
                "result": judge,
            }, ignore_index=True)

results_df.sort_values("File", inplace=True)  # ファイル名をアルファベット順にソート
results_df.to_excel("/Users/y.taisei/Desktop/submit_python/results_6.xlsx", index=False)




