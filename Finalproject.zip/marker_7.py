# 7. 4-grams
import os
import nltk
import pandas as pd
from nltk import ngrams
from collections import Counter
import matplotlib.pyplot as plt

folder_path = "/Users/y.taisei/Desktop/submit_python/archive"  
group_prefixes = ["Cleveland"]
n = 4  # 4-gram value
top_n = 10 # Top n frequent 4-grams


# Function to process a file and count 4-grams
def process_file(file_path):
    with open(file_path, "r") as file:
        text = file.read()

    tokens = nltk.word_tokenize(text)
    fourgrams_list = list(ngrams(tokens, n))

    return Counter(fourgrams_list)

def count_four_grams(text):
    tokens = nltk.word_tokenize(text)
    fourgrams_list = list(ngrams(tokens, n))
    return Counter(fourgrams_list)


for prefix in group_prefixes:
    file_paths = []  # List to store file paths

    # Process files in the folder with the given prefix
    for file_name in os.listdir(folder_path):
        file_path = os.path.join(folder_path, file_name)
        if os.path.isfile(file_path) and file_name.startswith(prefix):
            file_paths.append(file_path)

    if len(file_paths) == 0:
        print(f"No files found with the prefix '{prefix}'.")
        continue

    four_gram_counts = Counter()  # 4-gram counts

    # Count 4-grams for each file
    for file_path in file_paths:
        file_four_gram_counts = process_file(file_path)
        four_gram_counts += file_four_gram_counts

    # Calculate 4-gram frequencies
    total_four_grams = sum(four_gram_counts.values())
    four_gram_frequencies = {four_gram: count / total_four_grams for four_gram, count in four_gram_counts.items()}

    # Display the top n frequent 4-grams
    sorted_four_grams = sorted(four_gram_frequencies.items(), key=lambda x: x[1], reverse=True)
    top_four_grams = sorted_four_grams[:top_n]

    print(f"Top {top_n} 4-grams for prefix '{prefix}':")
    for four_gram, frequency in top_four_grams:
        print("4-gram:", " ".join(four_gram), "Frequency:", frequency)

    # Extract the 4-grams and frequencies for plotting
    labels = [" ".join(four_gram) for four_gram, _ in top_four_grams]
    frequencies = [frequency for _, frequency in top_four_grams]

    # Plot the frequencies as a bar graph
    plt.bar(labels, frequencies)
    plt.xlabel("4-gram")
    plt.ylabel("Frequency")
    plt.title(f"Top {top_n} 4-grams for prefix '{prefix}'")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig("/Users/y.taisei/Desktop/submit_python/result_7.png")
    plt.show()
    #plt.savefig("/Users/y.taisei/Desktop/submit_python/result_7.png")


results_df = pd.DataFrame(columns=["File", "result"])
# Process files in the folder
for file_name in os.listdir(folder_path):
    file_path = os.path.join(folder_path, file_name)
    if os.path.isfile(file_path):
        with open(file_path, "r") as file:
            text = file.read()

        # Count 4-grams for the file
        file_four_gram_counts = count_four_grams(text)
        file_total_four_grams = sum(file_four_gram_counts.values())
        file_four_gram_frequencies = {four_gram: count / file_total_four_grams for four_gram, count in file_four_gram_counts.items()}

        # Display the top n frequent 4-grams for the file
        sorted_file_four_grams = sorted(file_four_gram_frequencies.items(), key=lambda x: x[1], reverse=True)
        top_file_four_grams = sorted_file_four_grams[:top_n]

        print(f"Top {top_n} 4-grams for file '{file_name}':")
        for four_gram, frequency in top_file_four_grams:
            print("4-gram:", " ".join(four_gram), "Frequency:", frequency)

        print()

        #if,else
        #Check and compere TOP N 4-grams
        #存在する場合はjudge=1,存在しない場合はjudge=0
        
        if any(four_gram in four_gram_frequencies for four_gram, _ in top_file_four_grams):
            judge = 1
        else:
            judge = 0

        results_df = results_df.append({
            "File": file_name,
            "result": judge,
        }, ignore_index=True)

results_df.sort_values("File", inplace=True)  # ファイル名をアルファベット順にソート
results_df.to_excel("/Users/y.taisei/Desktop/submit_python/results_7.xlsx", index=False)
