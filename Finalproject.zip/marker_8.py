#8. infinitives vs gerunds(percent)
import os
import nltk
import pandas as pd

folder_path = "/Users/y.taisei/Desktop/submit_python/archive"
group_prefixes = ["Cleveland"]

# Function to process a file and count infinitives and gerunds
def process_file(file_path):
    with open(file_path, "r") as file:
        text = file.read()

    tokens = nltk.word_tokenize(text)
    pos_tags = nltk.pos_tag(tokens)

    infinitives_count = 0
    gerunds_count = 0

    for word, pos in pos_tags:
        if pos == 'VB':  # infinitives
            infinitives_count += 1
        elif pos == 'VBG':  # gerunds
            gerunds_count += 1

    return infinitives_count, gerunds_count


file_groups = {}  # Dictionary to store file groups and their counts

# Process files in the folder
for file_name in os.listdir(folder_path):
    file_path = os.path.join(folder_path, file_name)
    if os.path.isfile(file_path):
        group_name = None
        for prefix in group_prefixes:
            if file_name.startswith(prefix):
                group_name = prefix
                break
        if group_name is None:
            continue

        if group_name not in file_groups:
            file_groups[group_name] = {
                "infinitives_count": 0,
                "gerunds_count": 0,
                "file_count": 0
            }
        infinitives_count, gerunds_count = process_file(file_path)
        file_groups[group_name]["infinitives_count"] += infinitives_count
        file_groups[group_name]["gerunds_count"] += gerunds_count
        file_groups[group_name]["file_count"] += 1


averages = {}
for group_name, group_data in file_groups.items():
    average_infinitives = group_data["infinitives_count"] / group_data["file_count"]
    average_gerunds = group_data["gerunds_count"] / group_data["file_count"]

    authorship_value = average_infinitives / average_gerunds

    averages[group_name] = {
        "average_infinitives": average_infinitives,
        "average_gerunds": average_gerunds,
        "authorship_value": authorship_value,
    }

sorted_groups = sorted(averages.items(), key=lambda x: abs(x[1]["authorship_value"] - averages["Cleveland"]["authorship_value"]))
for group_name, group_data in sorted_groups:
    print()
    print("Group:", group_name)
    print("Difference in Authorship value with Group('Cleveland'):", abs(group_data["authorship_value"] - averages["Cleveland"]["authorship_value"]))
    print("Average Infinitives:", group_data["average_infinitives"])
    print("Average Gerunds:", group_data["average_gerunds"])
    print()

    if group_data["authorship_value"] > 1:
        print("Infinitives are dominant.")
    elif group_data["authorship_value"] < 1:
        print("Gerunds are dominant.")
    else:
        print("The number of Infinitives equals the number of Gerunds.")

results_df = pd.DataFrame(columns=["File", "Difference in Authorship Value", "infinitives", "gerunds", "result"])

for file_name in os.listdir(folder_path):
    #print(file_name)
    file_path = os.path.join(folder_path, file_name)
    if os.path.isfile(file_path):
            file_data = {
                "infinitives_count": 0,
                "gerunds_count": 0,
            }
            infinitives_count, gerunds_count = process_file(file_path)
            file_data["infinitives_count"] += infinitives_count
            file_data["gerunds_count"] += gerunds_count
            

            infinitives = file_data["infinitives_count"]
            gerunds = file_data["gerunds_count"]

            value = file_data["infinitives_count"] / file_data["gerunds_count"]
            
            print("File:", file_name)
            print("Difference in Authorship value with 'Cleveland' group:", abs(value - averages["Cleveland"]["authorship_value"]))
            print("infinitives:",infinitives)
            print("gerunds:", gerunds)
            print("value:",value)
            print()

            if abs(value - averages["Cleveland"]["authorship_value"]) < 0.6:
                judge = 1
                print("The text is more likely written by Cleveland.")
            elif abs(value - averages["Cleveland"]["authorship_value"]) > 0.6:
                judge = 0
                print("The text is more likely written by a different author.")
        
            results_df = results_df.append({
                "File": file_name,
                "Difference in Authorship Value": abs(value - averages["Cleveland"]["authorship_value"]),
                "infinitives": infinitives,
                "gerunds": gerunds,
                "result": judge,
            }, ignore_index=True)

results_df.sort_values("File", inplace=True)  # ファイル名をアルファベット順にソート
results_df.to_excel("/Users/y.taisei/Desktop/submit_python/results_8.xlsx", index=False)





