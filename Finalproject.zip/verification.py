import pandas as pd

# 元のExcelファイルのリスト
file_list = ["/Users/y.taisei/Desktop/submit_python/results_1.xlsx", "/Users/y.taisei/Desktop/submit_python/results_2.xlsx", "/Users/y.taisei/Desktop/submit_python/results_3.xlsx","/Users/y.taisei/Desktop/submit_python/results_4.xlsx",
             "/Users/y.taisei/Desktop/submit_python/results_5.xlsx","/Users/y.taisei/Desktop/submit_python/results_6.xlsx","/Users/y.taisei/Desktop/submit_python/results_7.xlsx",
             "/Users/y.taisei/Desktop/submit_python/results_8.xlsx","/Users/y.taisei/Desktop/submit_python/results_9.xlsx","/Users/y.taisei/Desktop/submit_python/results_10.xlsx"]

# 空のデータフレームを作成
combined_df = pd.DataFrame()

#"File_name"
df = pd.read_excel(file_list[0])
combined_df['File'] = df['File']

# 各ファイルから"result"列の値を取得し、結合する
for file in file_list:
    df = pd.read_excel(file)
    combined_df = pd.concat([combined_df, df['result']], axis=1)

combined_df['count'] = combined_df.iloc[:, 1:].sum(axis=1)
combined_df['verification'] = combined_df['count'].apply(lambda x: 'YES' if x == 10 else 'NO')

# 新しいExcelファイルに保存
combined_df.columns = ["File_name","result1", "result2", "result3","result4","result5","result6","result7","result8","result9","result10","count","verification"]
combined_df.to_excel("/Users/y.taisei/Desktop/submit_python/combined_results.xlsx", index=False)
